#ifndef THREADS_INTR_STYLE_H
#define THREADS_INTR_STYLE_H

/* Interrupt return path. */
void intr_exit_style (void);

#endif /* threads/intr-stubs.h */
